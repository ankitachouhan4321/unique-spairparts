# Unique Spairparts - Static Website

Files:
- index.html
- css/style.css
- img/logo.webp

Tech:
- HTML5
- CSS3
- Bootstrap 5.3
- Font Awesome
- AOS animations

Notes:
1. Open index.html directly in a browser or use VS Code Live Server.
2. Replace placeholder email/social links/contact details with the company's real details.
3. The enquiry form is intentionally static. Connect it to your preferred backend/form handler before launch.
4. Product cards can later be changed into separate product-detail pages if required.
